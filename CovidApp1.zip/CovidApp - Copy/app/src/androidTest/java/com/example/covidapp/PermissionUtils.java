package com.example.covidapp;

public class PermissionUtils {
    
}
